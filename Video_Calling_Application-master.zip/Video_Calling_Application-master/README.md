# Video_Calling_Application
Initial Commit on Video Calling Android Application
1) Android Studio 3.3 tool i used 
2) Permission which i used 	Internet ,Recoard_Audio,Camera Permission,Access_Network_state and self permission from users
3)  It will check for internet connection if no internet connection means it will show  Alert dialog
4) In mainActivity their is one image (+) sigin which is used to start video call 
5) once video started 3 images and one surfaceview will add came to live into fragment
   Left one for audio enable/disable 
   Right one for video enable/diable
   Middle one for Dissconnect call

JniLibs (Architecture)
This app is capable of different architecture 
arm64-v8a
armabi-v7a
x86
SDK Support  :
This time i used Agora.io as a sdk it is free for features so i used it.
1)https://sso.agora.io/en/login this is login website link which for agaora dashboard
2) Get Application ID from Dashboard and insert in strings.xml finish 
3)platform android for video calling their we have so many cool features
